package com.example.kaliumapp.ui.navigation

import android.content.Context
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.*
import com.example.kaliumapp.data.repository.UserRepository
import com.example.kaliumapp.remote.SharedPreferencesHelper
import com.example.kaliumapp.ui.DashboardScreen
import com.example.kaliumapp.ui.ProfileScreen
import com.example.kaliumapp.ui.auth.AuthScreen
import com.example.kaliumapp.ui.onboarding.OnboardingScreen
import com.example.kaliumapp.ui.screens.CalorieExpenditureScreen
import com.example.kaliumapp.ui.screens.CalorieIntakeScreen
import com.example.kaliumapp.ui.screens.FoodSearchScreen
import com.example.kaliumapp.ui.screens.WaterIntakeScreen
import com.example.kaliumapp.viewmodel.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Register : Screen("register")
    object Dashboard : Screen("dashboard")
    object Water : Screen("water")
    object Profile : Screen("profile")
    object CalorieIntake : Screen("calorie_intake")
    object CalorieExpenditure : Screen("calorie_expenditure")
    object Onboarding : Screen("onboarding")
    object FoodSearch : Screen("food_search")

    @Deprecated("Gunakan Login atau Register")
    object Auth : Screen("auth")
}

@Composable
fun AppNavigation(
    context: Context,
    startDestination: String,
    userRepository: UserRepository
) {
    val navController = rememberNavController()
    val coroutineScope = rememberCoroutineScope()

    var isLoaded by remember { mutableStateOf(false) }
    var currentStartDestination by remember { mutableStateOf(startDestination) }

    LaunchedEffect(Unit) {
        coroutineScope.launch(Dispatchers.IO) {
            val token = SharedPreferencesHelper.getToken(context)
            val isValid = token?.let {
                userRepository.validateToken("Bearer $it")
            } ?: false

            withContext(Dispatchers.Main) {
                currentStartDestination = when {
                    !isValid -> Screen.Login.route
                    !SharedPreferencesHelper.isOnboardingCompleted(context) -> Screen.Onboarding.route
                    else -> Screen.Dashboard.route
                }
                isLoaded = true
            }
        }
    }

    if (!isLoaded) return

    Scaffold(
        bottomBar = {
            val navBackStackEntry by navController.currentBackStackEntryAsState()
            val currentDestination = navBackStackEntry?.destination

            if (currentDestination?.route != Screen.Login.route &&
                currentDestination?.route != Screen.Register.route &&
                currentDestination?.route != Screen.Onboarding.route) {
                BottomNavigationBar(navController)
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = currentStartDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Login.route) {
                val authViewModel: AuthViewModel = hiltViewModel()
                AuthScreen(
                    navController = navController,
                    viewModel = authViewModel,
                    authType = "login"
                )
            }

            composable(Screen.Register.route) {
                val authViewModel: AuthViewModel = hiltViewModel()
                AuthScreen(
                    navController = navController,
                    viewModel = authViewModel,
                    authType = "register"
                )
            }

            composable(Screen.Dashboard.route) {
                DashboardScreen(navController)
            }

            composable(Screen.Water.route) {
                val waterIntakeViewModel: WaterIntakeViewModel = hiltViewModel()
                WaterIntakeScreen(navController = navController, waterIntakeViewModel = waterIntakeViewModel)
            }

            composable(Screen.Profile.route) {
                val profileViewModel: ProfileViewModel = hiltViewModel()
                val dashboardViewModel: DashboardViewModel = hiltViewModel()

                ProfileScreen(
                    viewModel = profileViewModel,
                    onLogoutClick = {
                        profileViewModel.logout {
                            dashboardViewModel.resetData()
                            navController.navigate(Screen.Login.route) {
                                popUpTo(Screen.Dashboard.route) { inclusive = true }
                            }
                        }
                    }
                )
            }

            composable(Screen.CalorieExpenditure.route) {
                val calorieExpenditureViewModel: CalorieExpenditureViewModel = hiltViewModel()
                CalorieExpenditureScreen(viewModel = calorieExpenditureViewModel, context = context)
            }

            composable(Screen.Onboarding.route) {
                OnboardingScreen(navController)
            }

            composable(Screen.Auth.route) {
                navController.navigate(Screen.Login.route) {
                    popUpTo(Screen.Auth.route) { inclusive = true }
                }
            }
            composable(Screen.CalorieIntake.route) {
                CalorieIntakeScreen(navController = navController) // sesuaikan jika butuh ViewModel
            }
            composable(Screen.FoodSearch.route) {
                FoodSearchScreen(
                    onFoodSelected = { selectedFood ->
                        navController.popBackStack()
                    },
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }

}


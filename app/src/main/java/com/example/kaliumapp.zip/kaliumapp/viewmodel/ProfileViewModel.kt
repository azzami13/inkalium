package com.example.kaliumapp.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kaliumapp.data.repository.UserRepository
import com.example.kaliumapp.model.UserResponse
import com.example.kaliumapp.remote.SharedPreferencesHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import android.util.Log
import javax.inject.Inject

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val userRepository: UserRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _profileState = MutableStateFlow<ProfileState>(ProfileState.Initial)
    val profileState: StateFlow<ProfileState> = _profileState

    init {
        loadUserProfile()
    }

    fun loadUserProfile() {
        val token = SharedPreferencesHelper.getToken(context)
        if (token != null) {
            loadProfileFromApi(token)
        } else {
            _profileState.value = ProfileState.Error("Anda belum login")
        }
    }

    fun loadProfileFromApi(token: String, onLoaded: ((UserResponse) -> Unit)? = null) {
        viewModelScope.launch {
            _profileState.value = ProfileState.Loading
            try {
                val user = userRepository.fetchUserProfileFromApi(token)
                if (user != null) {
                    _profileState.value = ProfileState.Success(user)
                    onLoaded?.invoke(user)
                } else {
                    _profileState.value = ProfileState.Error("Gagal mengambil data profil")
                }
            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error fetching profile: ${e.message}")
                _profileState.value = ProfileState.Error("Terjadi kesalahan: ${e.message}")
            }
        }
    }

    fun updateProfileToApi(updatedUser: UserResponse) {
        viewModelScope.launch {
            _profileState.value = ProfileState.Loading
            try {
                val token = SharedPreferencesHelper.getToken(context)
                Log.d("ProfileViewModel", "Token used for update: $token")
                if (token == null) {
                    _profileState.value = ProfileState.Error("Token tidak ditemukan, silakan login kembali")
                    return@launch
                }
                userRepository.updateUserToApi(updatedUser)
                _profileState.value = ProfileState.Success(updatedUser)
            } catch (e: Exception) {
                Log.e("ProfileViewModel", "Error updating profile: ${e.message}")
                _profileState.value = ProfileState.Error("Gagal memperbarui profil: ${e.message}")
            }
        }
    }

    fun uploadImageToServer(imagePath: String, onSuccess: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = File(imagePath)
            val response = userRepository.uploadImage(file)
            response?.let { filename ->
                withContext(Dispatchers.Main) {
                    onSuccess(filename)
                }
            } ?: run {
                withContext(Dispatchers.Main) {
                    _profileState.value = ProfileState.Error("Gagal mengunggah gambar")
                }
            }
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            SharedPreferencesHelper.clearToken(context)
            _profileState.value = ProfileState.Initial
            onLoggedOut()
        }
    }

    sealed class ProfileState {
        object Initial : ProfileState()
        object Loading : ProfileState()
        data class Success(val user: UserResponse) : ProfileState()
        data class Error(val message: String) : ProfileState()
    }
}
package com.example.kaliumapp.database.dao

import androidx.room.*
import com.example.kaliumapp.database.entities.WaterReminder

@Dao
interface WaterReminderDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReminder(reminder: WaterReminder)
    @Query("SELECT * FROM water_reminder WHERE summary_id = :summaryId")
    suspend fun getReminders(summaryId: Int): List<WaterReminder>

    @Query("UPDATE water_reminder SET status = 'Done' WHERE reminder_id = :reminderId")
    suspend fun markReminderAsDone(reminderId: Int)

    @Query("DELETE FROM water_reminder WHERE reminder_id = :reminderId")
    suspend fun deleteReminder(reminderId: Int)
}

package com.example.kaliumapp.database.dao

import androidx.room.*
import com.example.kaliumapp.database.entities.WaterIntake

@Dao
interface WaterIntakeDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIntake(intake: WaterIntake)

    @Query("SELECT SUM(intake_ml) FROM water_intake WHERE summary_id = :summaryId")
    suspend fun getTotalIntake(summaryId: Int): Int?

    @Query("DELETE FROM water_intake WHERE intake_id = :intakeId")
    suspend fun deleteIntake(intakeId: Int)
}

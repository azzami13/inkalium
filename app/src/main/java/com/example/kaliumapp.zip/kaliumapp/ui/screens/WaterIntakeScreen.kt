package com.example.kaliumapp.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kaliumapp.viewmodel.WaterIntakeViewModel
import androidx.navigation.NavHostController

@Composable
fun WaterIntakeScreen(
    navController: NavHostController, // Tambahkan parameter NavHostController
    waterIntakeViewModel: WaterIntakeViewModel = hiltViewModel()
) {
    var showCalculatorDialog by remember { mutableStateOf(false) }
    var showAddWaterDialog by remember { mutableStateOf(false) }
    var showReminderSettingsDialog by remember { mutableStateOf(false) }

    val waterIntake by waterIntakeViewModel.waterIntake.collectAsState()
    val totalWaterTarget by waterIntakeViewModel.totalWaterTarget.collectAsState()
    val reminderTimes by waterIntakeViewModel.reminderTimes.collectAsState()

    val progress = if (totalWaterTarget > 0) waterIntake.toFloat() / totalWaterTarget else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Water Intake",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )
            Button(onClick = { showCalculatorDialog = true }) {
                Text("Calculate")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Progress Circle
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Canvas(modifier = Modifier.size(250.dp)) {
                val strokeWidth = 25f
                val diameter = size.minDimension - strokeWidth
                val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)

                // Background circle
                drawArc(
                    color = Color.LightGray.copy(alpha = 0.3f),
                    startAngle = -90f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Progress circle
                drawArc(
                    color = Color(0xFFFFC107),
                    startAngle = -90f,
                    sweepAngle = 360f * progress,
                    useCenter = false,
                    topLeft = topLeft,
                    size = Size(diameter, diameter),
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )
            }

            // Text in the center of the circle
            Text(
                text = "${waterIntake.toInt()}/${totalWaterTarget.toInt()} ml",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Reminder Settings
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Reminder Settings", fontSize = 18.sp)
            Button(onClick = { showReminderSettingsDialog = true }) {
                Text("Configure")
            }
        }

        // Reminder Times
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(reminderTimes.size) { index ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(Color.Blue)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(reminderTimes[index], fontSize = 16.sp)
                }
            }
        }

        // Add Water Button
        FloatingActionButton(
            onClick = { showAddWaterDialog = true },
            containerColor = Color(0xFFFFC107),
            modifier = Modifier
                .align(Alignment.End)
                .padding(16.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = "Add Water"
            )
        }
    }

    // Dialogs (sama seperti sebelumnya)
    if (showCalculatorDialog) {
        WaterIntakeCalculatorDialog(
            onDismiss = { showCalculatorDialog = false },
            onCalculate = { gender, weight, age ->
                waterIntakeViewModel.calculateWaterIntake(gender, weight, age)
                showCalculatorDialog = false
            }
        )
    }

    if (showAddWaterDialog) {
        AddWaterIntakeDialog(
            onDismiss = { showAddWaterDialog = false },
            onAddWater = { amount ->
                waterIntakeViewModel.addWaterIntake(amount)
                showAddWaterDialog = false
            }
        )
    }

    if (showReminderSettingsDialog) {
        ReminderSettingsDialog(
            onDismiss = { showReminderSettingsDialog = false },
            onSave = { wakeUp, sleep, reminderCount ->
                waterIntakeViewModel.setWakeAndSleepTimes(wakeUp, sleep)
                waterIntakeViewModel.setReminderTimes(reminderCount)
                showReminderSettingsDialog = false
            }
        )
    }
}

@Composable
fun WaterIntakeCalculatorDialog(
    onDismiss: () -> Unit,
    onCalculate: (String, Double, Int) -> Unit
) {
    var gender by remember { mutableStateOf("male") }
    var weight by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Water Intake Calculator") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Gender Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { gender = "male" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (gender == "male") Color.Blue.copy(alpha = 0.1f) else Color.Transparent
                        )
                    ) {
                        Text("Male", color = if (gender == "male") Color.Blue else Color.Black)
                    }
                    OutlinedButton(
                        onClick = { gender = "female" },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (gender == "female") Color.Blue.copy(alpha = 0.1f) else Color.Transparent
                        )
                    ) {
                        Text("Female", color = if (gender == "female") Color.Blue else Color.Black)
                    }
                }

                // Weight Input
                OutlinedTextField(
                    value = weight,
                    onValueChange = {
                        weight = it.filter { char -> char.isDigit() || char == '.' }
                    },
                    label = { Text("Weight (kg)") },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                // Age Input
                OutlinedTextField(
                    value = age,
                    onValueChange = {
                        age = it.filter { char -> char.isDigit() }
                    },
                    label = { Text("Age (years)") },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val weightValue = weight.toDoubleOrNull() ?: 0.0
                    val ageValue = age.toIntOrNull() ?: 0

                    if (weightValue > 0 && ageValue > 0) {
                        onCalculate(gender, weightValue, ageValue)
                    } else {
                        // Tampilkan error
                    }
                }
            ) {
                Text("Calculate")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AddWaterIntakeDialog(
    onDismiss: () -> Unit,
    onAddWater: (Int) -> Unit
) {
    var amount by remember { mutableStateOf("200") }
    var preset by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Water Intake") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Preset Amounts
                Text("Preset Amounts", fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(200, 250, 300, 500).forEach { presetAmount ->
                        OutlinedButton(
                            onClick = {
                                amount = presetAmount.toString()
                                preset = true
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (amount.toIntOrNull() == presetAmount) Color.Blue.copy(alpha = 0.1f) else Color.Transparent
                            )
                        ) {
                            Text("$presetAmount ml")
                        }
                    }
                }

                // Custom Amount Input
                OutlinedTextField(
                    value = amount,
                    onValueChange = {
                        amount = it.filter { char -> char.isDigit() }
                        preset = false
                    },
                    label = { Text("Custom Amount (ml)") },
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val waterAmount = amount.toIntOrNull() ?: 200
                    onAddWater(waterAmount)
                }
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ReminderSettingsDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Int) -> Unit
) {
    var wakeUpTime by remember { mutableStateOf("06:00") }
    var sleepTime by remember { mutableStateOf("22:00") }
    var reminderCount by remember { mutableStateOf(6) }

    // Time picker state
    var showWakeUpTimePicker by remember { mutableStateOf(false) }
    var showSleepTimePicker by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reminder Settings") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Wake Up Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Wake Up Time")
                    TextButton(onClick = { showWakeUpTimePicker = true }) {
                        Text(wakeUpTime)
                    }
                }

                // Sleep Time
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Sleep Time")
                    TextButton(onClick = { showSleepTimePicker = true }) {
                        Text(sleepTime)
                    }
                }

                // Reminder Count
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Number of Reminders")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (reminderCount > 1) reminderCount-- },
                            enabled = reminderCount > 1
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }
                        Text(reminderCount.toString())
                        IconButton(
                            onClick = { if (reminderCount < 10) reminderCount++ },
                            enabled = reminderCount < 10
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(wakeUpTime, sleepTime, reminderCount)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )

    // Time Picker for Wake Up Time
    if (showWakeUpTimePicker) {
        TimePickerDialog(
            onDismiss = { showWakeUpTimePicker = false },
            onTimeSelected = {
                wakeUpTime = it
                showWakeUpTimePicker = false
            }
        )
    }

    // Time Picker for Sleep Time
    if (showSleepTimePicker) {
        TimePickerDialog(
            onDismiss = { showSleepTimePicker = false },
            onTimeSelected = {
                sleepTime = it
                showSleepTimePicker = false
            }
        )
    }
}

@Composable
fun TimePickerDialog(
    onDismiss: () -> Unit,
    onTimeSelected: (String) -> Unit
) {
    var hour by remember { mutableStateOf(6) }
    var minute by remember { mutableStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Time") },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Hour Picker
                    Column {
                        IconButton(
                            onClick = { if (hour < 23) hour++ },
                            enabled = hour < 23
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase Hour")
                        }
                        Text(
                            text = String.format("%02d", hour),
                            style = MaterialTheme.typography.headlineMedium
                        )
                        IconButton(
                            onClick = { if (hour > 0) hour-- },
                            enabled = hour > 0
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease Hour")
                        }
                    }

                    Text(":", style = MaterialTheme.typography.headlineMedium)

                    // Minute Picker
                    Column {
                        IconButton(
                            onClick = { if (minute < 59) minute++ },
                            enabled = minute < 59
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase Minute")
                        }
                        Text(
                            text = String.format("%02d", minute),
                            style = MaterialTheme.typography.headlineMedium
                        )
                        IconButton(
                            onClick = { if (minute > 0) minute-- },
                            enabled = minute > 0
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease Minute")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val formattedTime = String.format("%02d:%02d", hour, minute)
                    onTimeSelected(formattedTime)
                }
            ) {
                Text("Select")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
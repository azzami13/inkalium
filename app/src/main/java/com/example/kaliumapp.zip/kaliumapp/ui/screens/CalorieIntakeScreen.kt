package com.example.kaliumapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.kaliumapp.ui.components.NutrientBar
import com.example.kaliumapp.ui.components.ProgressRing
import com.example.kaliumapp.viewmodel.CalorieIntakeViewModel

@Composable
fun CalorieIntakeScreen(
    navController: NavController,
    viewModel: CalorieIntakeViewModel = hiltViewModel()
) {
    val dailyNutrients by viewModel.dailyNutrients.collectAsState()
    val totalCalories by viewModel.totalCalories.collectAsState()
    val calorieGoal by viewModel.calorieGoal.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Top Section with Calories Progress
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Calories",
                    style = MaterialTheme.typography.titleLarge
                )

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ProgressRing(
                        progress = (totalCalories / calorieGoal).coerceIn(0f, 1f),
                        centerText = {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Daily",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Nutrient",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        },
                        strokeWidth = 25.dp,
                        gradientColors = listOf(Color(0xFFFFEB3B), Color(0xFFFFC107))
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Nutrient Bars
                NutrientBar(
                    label = "Carbs",
                    value = dailyNutrients.carbs,
                    maxValue = 100f,
                    displayValue = "${dailyNutrients.carbs.toInt()}g",
                    color = Color.Blue,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Protein",
                    value = dailyNutrients.protein,
                    maxValue = 50f,
                    displayValue = "${dailyNutrients.protein.toInt()}g",
                    color = Color.Magenta,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Fat",
                    value = dailyNutrients.fat,
                    maxValue = 50f,
                    displayValue = "${dailyNutrients.fat.toInt()}g",
                    color = Color(0xFFFF9800),  // Orange
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Fiber",
                    value = dailyNutrients.fiber,
                    maxValue = 50f,
                    displayValue = "${dailyNutrients.fiber.toInt()}g",
                    color = Color.Green,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Sugar",
                    value = dailyNutrients.sugar,
                    maxValue = 15f,
                    displayValue = "${dailyNutrients.sugar.toInt()}g",
                    color = Color(0xFFE91E63),  // Pink
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Sodium",
                    value = dailyNutrients.sodium,
                    maxValue = 20f,
                    displayValue = "${dailyNutrients.sodium.toInt()}g",
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Search Food Button
        Button(
            onClick = {
                navController.navigate("food_search")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Search, contentDescription = "Search")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Cari Makanan")
        }

        // Tampilkan Riwayat Makanan yang Ditambahkan Hari Ini
        // ...
    }
}
package com.example.kaliumapp.viewmodel

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.ViewModel
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CalorieExpenditureViewModel : ViewModel(), SensorEventListener {

    private val _caloriesBurned = MutableStateFlow(0) // Kalori yang terbakar
    val caloriesBurned: StateFlow<Int> = _caloriesBurned

    private var stepCount = 0
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    // Kalori terbakar per langkah (perhitungan sederhana)
    private val caloriesPerStep = 0.05f // Misalnya, 0.05 kalori per langkah

    // Fungsi untuk memulai sensor
    fun startSensors(sensorManager: SensorManager) {
        this.sensorManager = sensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
    }

    // Fungsi untuk menghentikan sensor
    fun stopSensors() {
        sensorManager?.unregisterListener(this)
    }

    // Fungsi untuk menghitung kalori berdasarkan jumlah langkah
    private fun calculateCaloriesBurned(steps: Int) {
        val calories = (steps * caloriesPerStep).toInt()
        _caloriesBurned.value = calories
    }

    // Fungsi yang dipanggil saat sensor mendeteksi perubahan
    override fun onSensorChanged(event: SensorEvent?) {
        if (event != null && event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            // Menghitung jumlah langkah berdasarkan perubahan akselerasi
            val magnitude = Math.sqrt(
                (event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]).toDouble()
            )
            // Anggap magnitude lebih besar dari threshold berarti pergerakan langkah terdeteksi
            if (magnitude > 12) {
                stepCount++
                calculateCaloriesBurned(stepCount)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Tidak diperlukan dalam kasus ini
    }
}

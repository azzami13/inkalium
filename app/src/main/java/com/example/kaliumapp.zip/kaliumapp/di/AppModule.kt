package com.example.kaliumapp.di

import android.content.Context
import androidx.room.Room
import com.example.kaliumapp.data.repository.UserRepository
import com.example.kaliumapp.database.KaliumDatabase
import com.example.kaliumapp.database.dao.UserDao
import com.example.kaliumapp.remote.ApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): KaliumDatabase {
        return Room.databaseBuilder(
            context,
            KaliumDatabase::class.java,
            "kalium_database"
        ).fallbackToDestructiveMigration().build()
    }

    @Provides
    fun provideUserDao(database: KaliumDatabase): UserDao {
        return database.userDao()
    }

    @Provides
    @Singleton
    fun provideUserRepository(
        userDao: UserDao,
        apiService: ApiService,
        @ApplicationContext context: Context // Tambahkan context
    ): UserRepository {
        return UserRepository(userDao, apiService, context) // Sertakan context
    }
}
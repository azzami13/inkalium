package com.example.kaliumapp.model

data class FoodItem(
    val id: String,
    val name: String,
    val brand: String?,
    val calories: Float,
    val servingSize: Float,
    val servingUnit: String,
    val nutrients: Map<String, NutrientInfo>
)
package com.example.kaliumapp.database.dao

import androidx.room.*
import com.example.kaliumapp.database.entities.DailyWaterSummary

@Dao
interface DailyWaterSummaryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSummary(summary: DailyWaterSummary)

    @Query("SELECT * FROM daily_water_summary WHERE user_id = :userId AND date = :date LIMIT 1")
    suspend fun getSummaryByDate(userId: Int, date: String): DailyWaterSummary?

    @Query("UPDATE daily_water_summary SET total_intake_ml = :totalIntake, remaining_ml = :remainingMl WHERE summary_id = :summaryId")
    suspend fun updateWaterSummary(summaryId: Int, totalIntake: Int, remainingMl: Int)

    @Query("DELETE FROM daily_water_summary WHERE summary_id = :summaryId")
    suspend fun deleteSummary(summaryId: Int)
}

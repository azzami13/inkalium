package com.example.kaliumapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.kaliumapp.data.repository.UserRepository
import com.example.kaliumapp.remote.SharedPreferencesHelper
import com.example.kaliumapp.ui.navigation.AppNavigation
import com.example.kaliumapp.ui.navigation.Screen
import com.example.kaliumapp.ui.theme.KaliumTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
  class MainActivity : ComponentActivity() {

    @Inject
    lateinit var userRepository: UserRepository

    // Permission request callback
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { permissions ->
        val allPermissionsGranted = permissions.values.all { it }

        if (allPermissionsGranted) {
            // Permissions granted, proceed with navigation
            initializeApp()
        } else {
            // Permissions not granted, show a message or handle as needed
            Toast.makeText(this, "Permissions required for full functionality.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installSplashScreen()
        setContentView(R.layout.activity_splash)

        // Check if permissions are granted
        if (arePermissionsGranted()) {
            initializeApp()
        } else {
            requestPermissions()
        }
    }

    // Function to check if all necessary permissions are granted
    private fun arePermissionsGranted(): Boolean {
        val fineLocationPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseLocationPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val activityRecognitionPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED

        return fineLocationPermission && coarseLocationPermission && activityRecognitionPermission
    }

    // Request location and activity recognition permissions
    private fun requestPermissions() {
        requestPermissionLauncher.launch(
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACTIVITY_RECOGNITION
            )
        )
    }

    // Initialize the app after permissions are granted
    private fun initializeApp() {
        // Check token from SharedPreferences
        val token = SharedPreferencesHelper.getToken(this)

        // Determine which screen to show based on the presence of the token
        val startDestination = if (token.isNullOrEmpty()) Screen.Auth.route else Screen.Dashboard.route

        setContent {
            KaliumTheme {
                // Pass context, startDestination, and userRepository to AppNavigation
                AppNavigation(
                    context = this,
                    startDestination = startDestination,
                    userRepository = userRepository
                )
            }
        }
    }
}
package com.example.kaliumapp.remote

import com.example.kaliumapp.database.entities.User
import com.example.kaliumapp.model.AuthRequest
import com.example.kaliumapp.model.AuthResponse
import com.example.kaliumapp.model.FoodSearchResponse
import com.example.kaliumapp.model.UserResponse
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*

interface ApiService {

    @Headers("Content-Type: application/json")
    @POST("auth/login")
    suspend fun login(@Body request: AuthRequest): AuthResponse

    @Headers("Content-Type: application/json")
    @POST("auth/register")
    suspend fun register(@Body request: AuthRequest): AuthResponse

    @Headers("Content-Type: application/json")
    @PUT("auth/me")
    suspend fun updateUserProfile(
        @Header("Authorization") token: String,
        @Body user: UserResponse
    ): Response<UserResponse>

    @Multipart
    @POST("upload-photo")
    suspend fun uploadProfilePhoto(
        @Part file: MultipartBody.Part
    ): Response<ResponseBody>

    @GET("auth/me")
    suspend fun getCurrentUser(
        @Header("Authorization") token: String
    ): Response<UserResponse>

    @GET("api/food/search")
    suspend fun searchFood(@Query("query") query: String): FoodSearchResponse
}
package com.example.kaliumapp.data.repository

import android.content.Context
import com.example.kaliumapp.database.dao.UserDao
import com.example.kaliumapp.database.entities.User
import com.example.kaliumapp.model.UserResponse
import com.example.kaliumapp.remote.ApiService
import com.example.kaliumapp.remote.SharedPreferencesHelper
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserRepository @Inject constructor(
    private val userDao: UserDao,
    private val apiService: ApiService,
    private val context: Context // Tambahkan context untuk akses SharedPreferences
) {

    suspend fun getUserByEmail(email: String): User? {
        return userDao.getUserByEmail(email)
    }

    suspend fun getUserById(id: Int): User? {
        return userDao.getUserById(id)
    }

    suspend fun insertUser(user: User) {
        userDao.insertUser(user)
    }

    suspend fun updateLoginStats(id: Int, lastLogin: Long) {
        userDao.updateLoginStats(id, lastLogin)
    }

    suspend fun deleteUserById(id: Int) {
        val user = userDao.getUserById(id)
        if (user != null) {
            userDao.deleteUser(user.id)
        }
    }

    suspend fun updateUserProfile(updatedUser: User) {
        userDao.updateUser(updatedUser)
    }

    // Ambil profil user dari server menggunakan token
    suspend fun fetchUserProfileFromApi(token: String): UserResponse? {
        return try {
            val response = apiService.getCurrentUser("Bearer $token")
            if (response.isSuccessful) {
                val userResponse = response.body()
                // Simpan ke database lokal jika perlu
                userResponse?.let { apiUser ->
                    val localUser = User(
                        id = apiUser.id,
                        email = apiUser.email ?: "",
                        hashedPassword = "", // Password tidak disimpan dari API
                        username = apiUser.username,
                        role = "user", // Default role
                        umur = apiUser.umur ?: 0,
                        jenisKelamin = apiUser.jenisKelamin ?: "",
                        beratBadan = apiUser.beratBadan ?: 0.0,
                        tinggiBadan = apiUser.tinggiBadan ?: 0.0,
                        profileImage = apiUser.profileImage,
                        lastLogin = System.currentTimeMillis()
                    )
                    userDao.insertUser(localUser)
                }
                userResponse
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Update data user ke server
    suspend fun updateUserToApi(user: UserResponse) {
        val token = SharedPreferencesHelper.getToken(context)
            ?: throw IllegalStateException("Token tidak ditemukan, silakan login kembali")

        val response = apiService.updateUserProfile("Bearer $token", user)
        if (response.isSuccessful) {
            // Update ke database lokal jika berhasil
            val localUser = userDao.getUserById(user.id)
            localUser?.let {
                val updatedLocalUser = it.copy(
                    username = user.username,
                    umur = user.umur ?: 0,
                    jenisKelamin = user.jenisKelamin ?: "",
                    beratBadan = user.beratBadan ?: 0.0,
                    tinggiBadan = user.tinggiBadan ?: 0.0,
                    profileImage = user.profileImage
                )
                userDao.updateUser(updatedLocalUser)
            }
        } else {
            throw Exception("Gagal memperbarui profil: ${response.code()} ${response.message()}")
        }
    }

    // Upload gambar ke server dan kembalikan nama file dari respons
    suspend fun uploadImage(file: File): String? {
        return try {
            val requestBody = file.asRequestBody("image/*".toMediaTypeOrNull())
            val multipart = MultipartBody.Part.createFormData("file", file.name, requestBody)

            val response = apiService.uploadProfilePhoto(multipart)
            if (response.isSuccessful) {
                response.body()?.string()
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Validasi token
    suspend fun validateToken(token: String): Boolean {
        return try {
            val response = apiService.getCurrentUser("Bearer $token")
            response.isSuccessful
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
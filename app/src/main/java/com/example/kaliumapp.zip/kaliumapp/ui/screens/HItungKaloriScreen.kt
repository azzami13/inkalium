package com.example.kaliumapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.kaliumapp.viewmodel.HitungKaloriViewModel
import com.example.kaliumapp.ui.components.DropdownMenuAktivitas

@Composable
fun HitungKaloriScreen(viewModel: HitungKaloriViewModel) {
    val aktivitasList = viewModel.aktivitasList
    val selected = viewModel.selectedActivity
    val durasi = viewModel.duration
    val result = viewModel.result

    LaunchedEffect(Unit) {
        println("Aktivitas list: $aktivitasList") // Debug: Pastikan tidak kosong
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Pilih Jenis Olahraga", style = MaterialTheme.typography.titleMedium)

        Spacer(modifier = Modifier.height(8.dp))

        DropdownMenuAktivitas(
            items = aktivitasList,
            selectedItem = selected,
            onItemSelected = { viewModel.selectedActivity = it }
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = durasi,
            onValueChange = { viewModel.duration = it },
            label = { Text("Durasi (menit)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.hitungKalori() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Hitung Kalori")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = result)
    }
}

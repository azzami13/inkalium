package com.example.kaliumapp.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.kaliumapp.database.dao.UserDao
import com.example.kaliumapp.database.dao.WaterIntakeDao
import com.example.kaliumapp.database.dao.WaterReminderDao
import com.example.kaliumapp.database.dao.DailyWaterSummaryDao
import com.example.kaliumapp.database.entities.User
import com.example.kaliumapp.database.entities.WaterIntake
import com.example.kaliumapp.database.entities.WaterReminder
import com.example.kaliumapp.database.entities.DailyWaterSummary

@Database(
    entities = [
        User::class,
        WaterIntake::class,
        WaterReminder::class,
        DailyWaterSummary::class
    ],
    version = 3,
    exportSchema = false
)
abstract class KaliumDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun waterIntakeDao(): WaterIntakeDao
    abstract fun waterReminderDao(): WaterReminderDao
    abstract fun dailyWaterSummaryDao(): DailyWaterSummaryDao

    companion object {
        @Volatile
        private var INSTANCE: KaliumDatabase? = null

        fun getDatabase(context: Context): KaliumDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KaliumDatabase::class.java,
                    "kalium_database"
                )
                    .fallbackToDestructiveMigration() // Tambahkan migration jika dibutuhkan nanti
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

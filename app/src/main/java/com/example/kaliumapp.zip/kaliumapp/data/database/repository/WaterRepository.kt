package com.example.kaliumapp.database.repository

import com.example.kaliumapp.database.dao.*
import com.example.kaliumapp.database.entities.*
import com.example.kaliumapp.model.UserResponse
import com.example.kaliumapp.remote.ApiService

class WaterRepository(
    private val userDao: UserDao,
    private val dailyWaterSummaryDao: DailyWaterSummaryDao,
    private val waterIntakeDao: WaterIntakeDao,
    private val waterReminderDao: WaterReminderDao,
    private val apiService: ApiService
) {
    // User-related operations
    suspend fun insertUser(user: User) = userDao.insertUser(user)
    suspend fun getUserByEmail(email: String) = userDao.getUserByEmail(email)
    suspend fun updateLoginStats(id: Int, lastLogin: Long) = userDao.updateLoginStats(id, lastLogin)

    // Water summary operations
    suspend fun insertWaterSummary(summary: DailyWaterSummary) = dailyWaterSummaryDao.insertSummary(summary)
    suspend fun getWaterSummary(userId: Int, date: String) = dailyWaterSummaryDao.getSummaryByDate(userId, date)

    // Water intake operations
    suspend fun insertWaterIntake(intake: WaterIntake) = waterIntakeDao.insertIntake(intake)
    suspend fun getTotalWaterIntake(summaryId: Int) = waterIntakeDao.getTotalIntake(summaryId)

    // Water reminder operations
    suspend fun insertWaterReminder(reminder: WaterReminder) = waterReminderDao.insertReminder(reminder)
    suspend fun getWaterReminders(summaryId: Int) = waterReminderDao.getReminders(summaryId)
    suspend fun markReminderAsDone(reminderId: Int) = waterReminderDao.markReminderAsDone(reminderId)

    // Sync with remote API
    suspend fun syncDataToServer(user: User) {
        // Konversi User ke UserResponse untuk dikirim ke API
        val userResponse = UserResponse(
            id = user.id,
            email = user.email,
            username = user.username,
            umur = user.umur,
            jenisKelamin = user.jenisKelamin,
            beratBadan = user.beratBadan,
            tinggiBadan = user.tinggiBadan,
            profileImage = user.profileImage
        )
        try {
            // Gunakan endpoint /auth/me untuk sinkronisasi
            val response = apiService.updateUserProfile("Bearer ${user.id}", userResponse)
            if (response.isSuccessful) {
                // Update lokal jika perlu
                response.body()?.let { updatedUser ->
                    val updatedLocalUser = user.copy(
                        username = updatedUser.username,
                        umur = updatedUser.umur ?: 0,
                        jenisKelamin = updatedUser.jenisKelamin ?: "",
                        beratBadan = updatedUser.beratBadan ?: 0.0,
                        tinggiBadan = updatedUser.tinggiBadan ?: 0.0,
                        profileImage = updatedUser.profileImage
                    )
                    userDao.updateUser(updatedLocalUser)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
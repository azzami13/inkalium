package com.example.kaliumapp.repository

import com.example.kaliumapp.database.entities.User
import com.example.kaliumapp.database.dao.UserDao
import javax.inject.Inject

class CalorieRepository @Inject constructor(
    private val userDao: UserDao
) {
    // Fungsi untuk menyimpan asupan kalori
    suspend fun saveCalorieIntake(calories: Int) {
        // Misalnya, kita simpan asupan kalori ke dalam User atau ke entitas lain
        val user = userDao.getUserById(1) // ambil user dengan id tertentu
        user?.let {
            // Update asupan kalori
            it.beratBadan += calories // contoh perhitungan (bisa disesuaikan)
            userDao.updateUser(it)
        }
    }
}

package com.example.kaliumapp.data.database.repository

import com.example.kaliumapp.model.FoodItem
import com.example.kaliumapp.model.FoodSearchResponse
import com.example.kaliumapp.remote.EdamamApiService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FoodRepository @Inject constructor(
    private val edamamApiService: EdamamApiService
) {
    // Konstanta untuk API Keys
    companion object {
        private const val APP_ID = "YOUR_EDAMAM_APP_ID"
        private const val APP_KEY = "YOUR_EDAMAM_APP_KEY"
    }

    suspend fun searchFood(query: String): FoodSearchResponse {
        return edamamApiService.searchFood(APP_ID, APP_KEY, query)
    }

    suspend fun getFoodDetails(foodId: String): FoodItem {
        // Implementasi untuk mendapatkan detail makanan
        // Jika diperlukan, gunakan endpoint terpisah atau filter dari hasil pencarian
        val response = edamamApiService.searchFood(APP_ID, APP_KEY, foodId)
        return response.foodItems.first { it.id == foodId }
    }
}
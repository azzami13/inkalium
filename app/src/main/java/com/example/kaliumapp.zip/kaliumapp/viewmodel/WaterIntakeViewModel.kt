package com.example.kaliumapp.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.*

class WaterIntakeViewModel : ViewModel() {
    private val _waterIntake = MutableStateFlow(0)
    val waterIntake: StateFlow<Int> = _waterIntake

    private val _totalWaterTarget = MutableStateFlow(0)
    val totalWaterTarget: StateFlow<Int> = _totalWaterTarget

    private val _reminderTimes = MutableStateFlow<List<String>>(listOf())
    val reminderTimes: StateFlow<List<String>> = _reminderTimes

    private val _wakeUpTime = MutableStateFlow("06:00")
    val wakeUpTime: StateFlow<String> = _wakeUpTime

    private val _sleepTime = MutableStateFlow("22:00")
    val sleepTime: StateFlow<String> = _sleepTime

    // Fungsi untuk menghitung kebutuhan air berdasarkan gender, berat badan, dan usia
    fun calculateWaterIntake(gender: String, weight: Double, age: Int) {
        var requiredWater = (weight * 30).toInt() // Berdasarkan 30ml per kg berat badan

        // Menyesuaikan kebutuhan cairan berdasarkan gender
        if (gender == "female") {
            requiredWater = (requiredWater * 0.9).toInt()
        }

        // Menyesuaikan berdasarkan usia
        if (age > 50) {
            requiredWater = (requiredWater * 0.85).toInt()
        }

        // Menyimpan hasil perhitungan ke state
        _totalWaterTarget.value = requiredWater
        _waterIntake.value = 0
    }

    // Fungsi untuk mengatur waktu bangun dan tidur
    fun setWakeAndSleepTimes(wakeUp: String, sleep: String) {
        _wakeUpTime.value = wakeUp
        _sleepTime.value = sleep
    }

    // Fungsi untuk membuat pengingat berdasarkan waktu bangun, tidur, dan jumlah pengingat
    fun setReminderTimes(numberOfReminders: Int) {
        val startTime = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(_wakeUpTime.value)
        val endTime = SimpleDateFormat("HH:mm", Locale.getDefault()).parse(_sleepTime.value)

        val waterPerReminder = _totalWaterTarget.value / numberOfReminders
        val reminderList = mutableListOf<String>()

        // Hitung interval antara pengingat
        val timeDiff = endTime.time - startTime.time
        val interval = timeDiff / (numberOfReminders + 1)

        for (i in 1..numberOfReminders) {
            val reminderTimeMillis = startTime.time + (i * interval)
            val reminderTime = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(reminderTimeMillis))
            reminderList.add(reminderTime)
        }

        _reminderTimes.value = reminderList
    }

    // Fungsi untuk menambah intake air
    fun addWaterIntake(amount: Int) {
        val newIntake = _waterIntake.value + amount
        _waterIntake.value = minOf(newIntake, _totalWaterTarget.value)
    }

    // Reset intake air harian
    fun resetDailyIntake() {
        _waterIntake.value = 0
    }
}
package com.example.kaliumapp.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.kaliumapp.model.ActivityItem

class HitungKaloriViewModel : ViewModel() {
    var selectedActivity by mutableStateOf<ActivityItem?>(null)
    var duration by mutableStateOf("")
    var result by mutableStateOf("")

    private val beratBadan = 65.0

    val aktivitasList = listOf(
        ActivityItem("Jalan Santai", 3.5),
        ActivityItem("Lari Ringan", 6.0),
        ActivityItem("Bersepeda", 4.0),
        ActivityItem("Renang", 5.8)
    )

    fun hitungKalori() {
        val durasiInt = duration.toIntOrNull()
        val met = selectedActivity?.met ?: return

        if (durasiInt != null && durasiInt > 0) {
            val durasiJam = durasiInt / 60.0
            val kalori = met * beratBadan * durasiJam
            result = "Kalori terbakar: %.2f kkal".format(kalori)
        } else {
            result = "Masukkan durasi yang valid"
        }
    }
}

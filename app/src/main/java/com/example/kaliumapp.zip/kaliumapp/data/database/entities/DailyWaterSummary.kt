package com.example.kaliumapp.database.entities

import androidx.room.*

@Entity(
    tableName = "daily_water_summary",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["id"],
        childColumns = ["user_id"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index(value = ["user_id"])] // ← Ini juga wajib
)
data class DailyWaterSummary(
    @PrimaryKey(autoGenerate = true) @ColumnInfo(name = "summary_id") val summaryId: Int = 0,
    @ColumnInfo(name = "user_id") val userId: Int,
    val date: String,
    @ColumnInfo(name = "total_intake_ml") val totalIntakeMl: Int = 0,
    @ColumnInfo(name = "remaining_ml") val remainingMl: Int = 0,
    val status: String
)


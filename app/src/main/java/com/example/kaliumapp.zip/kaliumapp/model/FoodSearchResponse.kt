package com.example.kaliumapp.model

data class FoodSearchResponse(
    val foodItems: List<FoodItem>,
    val totalResults: Int
)
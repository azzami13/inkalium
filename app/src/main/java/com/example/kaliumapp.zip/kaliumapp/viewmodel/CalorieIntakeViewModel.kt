package com.example.kaliumapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kaliumapp.data.database.repository.FoodRepository
import com.example.kaliumapp.model.FoodItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import javax.inject.Inject

data class DailyNutrients(
    val carbs: Float = 0f,
    val protein: Float = 0f,
    val fat: Float = 0f,
    val fiber: Float = 0f,
    val sugar: Float = 0f,
    val sodium: Float = 0f
)

@HiltViewModel
class CalorieIntakeViewModel @Inject constructor(
    private val foodRepository: FoodRepository
    // Tambahkan repository lain yang diperlukan
) : ViewModel() {

    private val _dailyNutrients = MutableStateFlow(DailyNutrients())
    val dailyNutrients: StateFlow<DailyNutrients> = _dailyNutrients

    private val _totalCalories = MutableStateFlow(0f)
    val totalCalories: StateFlow<Float> = _totalCalories

    private val _calorieGoal = MutableStateFlow(2000f)  // Default goal
    val calorieGoal: StateFlow<Float> = _calorieGoal

    private val _foodItems = MutableStateFlow<List<FoodItem>>(emptyList())
    val foodItems: StateFlow<List<FoodItem>> = _foodItems

    init {
        loadDailyNutrients()
    }

    private fun loadDailyNutrients() {
        // Ini bisa diimplementasikan untuk memuat data dari database lokal
        // Untuk contoh ini, kita gunakan nilai statis
        _dailyNutrients.value = DailyNutrients(
            carbs = 45f,
            protein = 25f,
            fat = 20f,
            fiber = 8f,
            sugar = 10f,
            sodium = 5f
        )
        _totalCalories.value = 1200f
    }

    fun addFoodItem(foodItem: FoodItem) {
        viewModelScope.launch {
            // Tambahkan ke daftar makanan
            val currentItems = _foodItems.value.toMutableList()
            currentItems.add(foodItem)
            _foodItems.value = currentItems

            // Update nutrisi harian
            updateDailyNutrients(foodItem)
        }
    }

    private fun updateDailyNutrients(foodItem: FoodItem) {
        val current = _dailyNutrients.value

        // Update kalori total
        _totalCalories.value += foodItem.calories

        // Update nutrisi
        _dailyNutrients.value = DailyNutrients(
            carbs = current.carbs + (foodItem.nutrients["CHOCDF"]?.quantity ?: 0f),
            protein = current.protein + (foodItem.nutrients["PROCNT"]?.quantity ?: 0f),
            fat = current.fat + (foodItem.nutrients["FAT"]?.quantity ?: 0f),
            fiber = current.fiber + (foodItem.nutrients["FIBTG"]?.quantity ?: 0f),
            sugar = current.sugar + (foodItem.nutrients["SUGAR"]?.quantity ?: 0f),
            sodium = current.sodium + (foodItem.nutrients["NA"]?.quantity ?: 0f)
        )
    }
}
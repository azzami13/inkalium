package com.example.kaliumapp.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.kaliumapp.model.AuthRequest
import com.example.kaliumapp.model.AuthResponse
import com.example.kaliumapp.remote.ApiService
import com.example.kaliumapp.remote.SharedPreferencesHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import android.util.Log

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val apiService: ApiService,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState

    fun checkLoginStatus() {
        if (SharedPreferencesHelper.isLoggedIn(context)) {
            _authState.value = AuthState.AlreadyLoggedIn
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _authState.value = AuthState.Error("Email dan password harus diisi")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val response = apiService.login(AuthRequest(email, password))

                if (response.success && response.token != null) {
                    SharedPreferencesHelper.saveToken(context, response.token)
                    _authState.value = AuthState.Success(response)
                } else {
                    _authState.value = AuthState.Error(response.message ?: "Login gagal")
                }
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Error saat login", e)
                _authState.value = AuthState.Error("Terjadi kesalahan jaringan")
            }
        }
    }

    fun register(email: String, password: String, confirmPassword: String) {
        if (email.isBlank() || password.isBlank()) {
            _authState.value = AuthState.Error("Email dan password harus diisi")
            return
        }

        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val response = apiService.register(AuthRequest(email, password))
                if (response.success && response.token != null) {
                    SharedPreferencesHelper.saveToken(context, response.token)
                    _authState.value = AuthState.Success(response)
                } else {
                    _authState.value = AuthState.Error(response.message ?: "Registrasi gagal")
                }
            } catch (e: Exception) {
                Log.e("AuthViewModel", "Error saat registrasi", e)
                _authState.value = AuthState.Error("Terjadi kesalahan jaringan")
            }
        }
    }

    fun logout() {
        SharedPreferencesHelper.clearAll(context)
        _authState.value = AuthState.Idle
    }

    sealed class AuthState {
        object Idle : AuthState()
        object Loading : AuthState()
        object AlreadyLoggedIn : AuthState()
        data class Success(val response: AuthResponse) : AuthState()
        data class Error(val message: String) : AuthState()
    }
}
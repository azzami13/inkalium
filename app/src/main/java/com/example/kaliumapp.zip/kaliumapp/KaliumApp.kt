package com.example.kaliumapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class KaliumApp : Application()

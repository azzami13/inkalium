package com.example.kaliumapp.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * ProgressRing adalah komponen lingkaran progres yang menampilkan persentase dengan gradien warna.
 *
 * @param progress Nilai progres dari 0.0f hingga 1.0f
 * @param modifier Modifier untuk menyesuaikan tampilan komponen
 * @param strokeWidth Ketebalan garis lingkaran
 * @param gradientColors Daftar warna untuk gradien yang digunakan pada progres lingkaran
 * @param backgroundColor Warna latar belakang lingkaran
 * @param centerText Konten yang ditampilkan di tengah lingkaran (opsional)
 */
@Composable
fun ProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    strokeWidth: Dp = 16.dp,
    gradientColors: List<Color> = listOf(Color.Blue, Color.Cyan),
    backgroundColor: Color = Color.LightGray.copy(alpha = 0.3f),
    centerText: @Composable (() -> Unit)? = null
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .size(200.dp) // Default size, bisa diubah dengan modifier
        ) {
            // Ukuran dan posisi lingkaran
            val canvasSize = size
            val radius = (canvasSize.minDimension - strokeWidth.toPx()) / 2
            val center = Offset(canvasSize.width / 2, canvasSize.height / 2)

            // Sudut awal dan sweep angle untuk lingkaran progres
            val startAngle = -90f // Mulai dari atas
            val sweepAngle = 360f * progress

            // Buat lingkaran latar belakang
            drawArc(
                color = backgroundColor,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(
                    center.x - radius,
                    center.y - radius
                ),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            )

            // Buat lingkaran progres dengan gradien
            val brush = Brush.linearGradient(
                colors = gradientColors,
                start = Offset(center.x - radius, center.y),
                end = Offset(center.x + radius, center.y)
            )

            drawArc(
                brush = brush,
                startAngle = startAngle,
                sweepAngle = sweepAngle,
                useCenter = false,
                topLeft = Offset(
                    center.x - radius,
                    center.y - radius
                ),
                size = Size(radius * 2, radius * 2),
                style = Stroke(width = strokeWidth.toPx(), cap = StrokeCap.Round)
            )
        }

        // Tampilkan teks di tengah jika ada
        centerText?.invoke()
    }
}
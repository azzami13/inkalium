package com.example.kaliumapp.ui.screens

import android.content.Context
import android.hardware.SensorManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kaliumapp.viewmodel.CalorieExpenditureViewModel

@Composable
fun CalorieExpenditureScreen(
    viewModel: CalorieExpenditureViewModel = hiltViewModel(),  // Corrected to use the correct viewModel type
    context: Context  // Accept Context for sensor access
) {
    val caloriesBurned by viewModel.caloriesBurned.collectAsState()

    // Start the sensor when the screen is launched
    LaunchedEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        viewModel.startSensors(sensorManager)
    }

    // Stop the sensor when the screen is disposed
    DisposableEffect(Unit) {
        onDispose {
            viewModel.stopSensors() // Stop the sensor tracking when screen is disposed
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Calorie Expenditure",
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Display the calories burned today based on sensor movement
        Text(
            text = "Calories Burned Today: $caloriesBurned kcal",
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Button to stop sensor tracking
        Button(
            onClick = { viewModel.stopSensors() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Stop Tracking")
        }
    }
}

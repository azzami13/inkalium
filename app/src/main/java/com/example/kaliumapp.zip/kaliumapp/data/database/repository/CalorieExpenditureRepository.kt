package com.example.kaliumapp.repository

import com.example.kaliumapp.database.entities.User
import com.example.kaliumapp.database.dao.UserDao
import javax.inject.Inject

class CalorieExpenditureRepository @Inject constructor(
    private val userDao: UserDao
) {
    // Fungsi untuk menyimpan pengeluaran kalori
    suspend fun saveCalorieExpenditure(activityType: String, duration: Int) {
        // Misalnya, kita simpan pengeluaran kalori berdasarkan aktivitas dan durasi
        val user = userDao.getUserById(1) // ambil user dengan id tertentu
        user?.let {
            // Update pengeluaran kalori sesuai aktivitas
            val expenditure = when (activityType) {
                "Running" -> duration * 10 // contoh, lari membakar 10 kalori per menit
                "Walking" -> duration * 5 // contoh, berjalan membakar 5 kalori per menit
                else -> 0
            }
            it.beratBadan -= expenditure // contoh perhitungan pengeluaran kalori
            userDao.updateUser(it)
        }
    }
}

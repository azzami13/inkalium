package com.example.kaliumapp.database.dao

import androidx.room.*
import com.example.kaliumapp.database.entities.User

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: Int): User?

    @Query("UPDATE users SET lastLogin = :lastLogin, loginCount = loginCount + 1 WHERE id = :id")
    suspend fun updateLoginStats(id: Int, lastLogin: Long)

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: Int)

    @Update
    suspend fun updateUser(user: User)  // Update data pengguna yang sudah ada
}

package com.example.kaliumapp.ui.onboarding

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.kaliumapp.remote.SharedPreferencesHelper
import com.example.kaliumapp.ui.navigation.Screen
import com.example.kaliumapp.viewmodel.OnboardingViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    navController: NavController,
    onboardingViewModel: OnboardingViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    var step by remember { mutableStateOf(0) }

    val username by onboardingViewModel.username.collectAsState()
    val umur by onboardingViewModel.umur.collectAsState()
    val jenisKelamin by onboardingViewModel.jenisKelamin.collectAsState()
    val beratBadan by onboardingViewModel.beratBadan.collectAsState()
    val tinggiBadan by onboardingViewModel.tinggiBadan.collectAsState()

    val coroutineScope = rememberCoroutineScope()

    val onboardingSteps = listOf(
        "Masukkan Username",
        "Masukkan Umur",
        "Pilih Jenis Kelamin",
        "Masukkan Berat Badan",
        "Masukkan Tinggi Badan",
        "Syarat & Ketentuan"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(onboardingSteps[step], style = MaterialTheme.typography.headlineSmall)

        Spacer(modifier = Modifier.height(24.dp))

        // Input berdasarkan langkah
        when (step) {
            0 -> {
                OutlinedTextField(
                    value = username,
                    onValueChange = { onboardingViewModel.updateUsername(it) },
                    label = { Text("Username") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
            1 -> {
                OutlinedTextField(
                    value = umur,
                    onValueChange = { onboardingViewModel.updateUmur(it) },
                    label = { Text("Umur") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            2 -> {
                val options = listOf("Laki-laki", "Perempuan")
                options.forEach { option ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .selectable(
                                selected = jenisKelamin == option,
                                onClick = { onboardingViewModel.updateJenisKelamin(option) }
                            )
                            .padding(8.dp)
                    ) {
                        RadioButton(
                            selected = jenisKelamin == option,
                            onClick = null
                        )
                        Text(
                            text = option,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
            }
            3 -> {
                OutlinedTextField(
                    value = beratBadan,
                    onValueChange = { onboardingViewModel.updateBeratBadan(it) },
                    label = { Text("Berat Badan (kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            4 -> {
                OutlinedTextField(
                    value = tinggiBadan,
                    onValueChange = { onboardingViewModel.updateTinggiBadan(it) },
                    label = { Text("Tinggi Badan (cm)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            5 -> {
                Text(
                    text = "Dengan melanjutkan, Anda menyetujui Syarat & Ketentuan serta Kebijakan Privasi kami.",
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        Button(
            onClick = {
                if (step < onboardingSteps.size - 1) {
                    step++
                } else {
                    coroutineScope.launch {
                        onboardingViewModel.saveOnboardingData()
                        navController.navigate(Screen.Dashboard.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (step < onboardingSteps.size - 1) "Selanjutnya" else "Memulai")
        }

        if (step > 0) {
            TextButton(
                onClick = { step-- },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("Kembali")
            }
        }
    }
}
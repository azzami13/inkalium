package com.example.kaliumapp.model

data class NutrientInfo(
    val label: String,
    val quantity: Float,
    val unit: String
)
package com.example.kaliumapp.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kaliumapp.model.FoodItem

@Composable
fun FoodItemCard(
    foodItem: FoodItem,
    onClick: (FoodItem) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable { onClick(foodItem) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = foodItem.name,
                style = MaterialTheme.typography.titleMedium
            )

            if (foodItem.brand != null) {
                Text(
                    text = foodItem.brand,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Kalori",
                    style = MaterialTheme.typography.bodySmall
                )

                Text(
                    text = "${foodItem.calories.toInt()} kcal / ${foodItem.servingSize} ${foodItem.servingUnit}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
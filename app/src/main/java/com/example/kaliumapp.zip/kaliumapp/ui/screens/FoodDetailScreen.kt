package com.example.kaliumapp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.kaliumapp.model.FoodItem
import com.example.kaliumapp.ui.components.NutrientBar
import com.example.kaliumapp.ui.components.ProgressRing
import com.example.kaliumapp.viewmodel.FoodSearchViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoodDetailScreen(
    foodId: String,
    onNavigateBack: () -> Unit,
    onAddFood: (FoodItem) -> Unit,
    viewModel: FoodSearchViewModel = hiltViewModel()
) {
    val foodItem by viewModel.selectedFood.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()

    LaunchedEffect(foodId) {
        viewModel.getFoodDetails(foodId)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        SmallTopAppBar(
            title = { Text("Detail Makanan") },
            navigationIcon = {
                IconButton(onClick = onNavigateBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Kembali")
                }
            },
            actions = {
                IconButton(onClick = {
                    foodItem?.let { onAddFood(it) }
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Tambah Makanan")
                }
            }
        )

        if (isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (error != null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Error: ${error?.message}")
            }
        } else if (foodItem != null) {
            val item = foodItem!!

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header dengan informasi makanan
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.headlineMedium
                )

                if (item.brand != null) {
                    Text(
                        text = item.brand,
                        style = MaterialTheme.typography.bodyLarge
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Progress Ring untuk kalori
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    ProgressRing(
                        progress = 0.7f,  // Ini bisa didasarkan pada persentase dari total kalori harian
                        centerText = {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Daily",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Nutrient",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        },
                        strokeWidth = 25.dp,
                        gradientColors = listOf(Color(0xFFFFEB3B), Color(0xFFFFC107))
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Nutrient Bars
                val nutrients = item.nutrients

                NutrientBar(
                    label = "Carbs",
                    value = nutrients["CHOCDF"]?.quantity ?: 0f,
                    maxValue = 100f,
                    displayValue = "${nutrients["CHOCDF"]?.quantity?.toInt() ?: 0}g",
                    color = Color.Blue,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Protein",
                    value = nutrients["PROCNT"]?.quantity ?: 0f,
                    maxValue = 50f,
                    displayValue = "${nutrients["PROCNT"]?.quantity?.toInt() ?: 0}g",
                    color = Color.Magenta,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Fat",
                    value = nutrients["FAT"]?.quantity ?: 0f,
                    maxValue = 50f,
                    displayValue = "${nutrients["FAT"]?.quantity?.toInt() ?: 0}g",
                    color = Color(0xFFFF9800),  // Orange
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Fiber",
                    value = nutrients["FIBTG"]?.quantity ?: 0f,
                    maxValue = 50f,
                    displayValue = "${nutrients["FIBTG"]?.quantity?.toInt() ?: 0}g",
                    color = Color.Green,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Sugar",
                    value = nutrients["SUGAR"]?.quantity ?: 0f,
                    maxValue = 15f,
                    displayValue = "${nutrients["SUGAR"]?.quantity?.toInt() ?: 0}g",
                    color = Color(0xFFE91E63),  // Pink
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                NutrientBar(
                    label = "Sodium",
                    value = nutrients["NA"]?.quantity ?: 0f,
                    maxValue = 20f,
                    displayValue = "${nutrients["NA"]?.quantity?.toInt() ?: 0}g",
                    color = Color.Gray,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
            }
        }
    }
}